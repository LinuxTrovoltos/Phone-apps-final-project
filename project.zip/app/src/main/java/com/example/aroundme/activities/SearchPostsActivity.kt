package com.example.aroundme.activities

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.aroundme.R
import com.example.aroundme.adapters.PostAdapter
import com.example.aroundme.models.Post
import com.google.firebase.firestore.FirebaseFirestore

class SearchPostsActivity : AppCompatActivity() {

    private lateinit var searchInput: EditText
    private lateinit var categorySpinner: Spinner
    private lateinit var recyclerView: RecyclerView
    private lateinit var postAdapter: PostAdapter
    private val postList = mutableListOf<Post>()
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_posts)

        searchInput = findViewById(R.id.search_input)
        categorySpinner = findViewById(R.id.category_spinner)
        recyclerView = findViewById(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)
        postAdapter = PostAdapter(postList)
        recyclerView.adapter = postAdapter

        findViewById<Button>(R.id.search_button).setOnClickListener {
            searchPosts(searchInput.text.toString(), categorySpinner.selectedItem.toString())
        }
    }

    private fun searchPosts(query: String, category: String) {
        val searchQuery = db.collection("posts")

        if (query.isNotEmpty()) {
            searchQuery.whereEqualTo("title", query)
        }
        if (category != "All") {
            searchQuery.whereEqualTo("category", category)
        }

        searchQuery.get()
            .addOnSuccessListener { documents ->
                postList.clear()
                for (document in documents) {
                    val post = document.toObject(Post::class.java)
                    postList.add(post)
                }
                postAdapter.notifyDataSetChanged()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Search failed", Toast.LENGTH_SHORT).show()
            }
    }
}
