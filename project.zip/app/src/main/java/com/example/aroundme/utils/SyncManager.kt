package com.example.aroundme.utils

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import androidx.lifecycle.lifecycleScope
import com.example.aroundme.database.PostDatabase
import com.example.aroundme.models.Post
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class SyncManager : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (isInternetAvailable(context)) {
            syncOfflinePosts(context)
        }
    }

    private fun syncOfflinePosts(context: Context) {
        val db = FirebaseFirestore.getInstance()
        val postDatabase = PostDatabase.getDatabase(context)

        GlobalScope.launch(Dispatchers.IO) {
            val offlinePosts = postDatabase.postDao().getAllPosts()

            for (post in offlinePosts) {
                db.collection("posts").add(post)
                    .addOnSuccessListener {
                        Log.d("SyncManager", "Offline post synced: ${post.title}")
                        GlobalScope.launch(Dispatchers.IO) {
                            postDatabase.postDao().deleteAllPosts()
                        }
                    }
                    .addOnFailureListener {
                        Log.e("SyncManager", "Failed to sync post: ${post.title}")
                    }
            }
        }
    }

    private fun isInternetAvailable(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}
